package pageobjects;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class OrbitzPageObjects {
	WebDriver driver;
	public String projectDirectory;
	
	By tab_Flights=By.xpath("//span[@class='uitk-tab-text' and text()='Flights']");
	By tab_RoundTrip=By.xpath("//span[@class='uitk-tab-text' and text()='Roundtrip']");
	By btn_LeavingFrom=By.xpath("//button[contains(@aria-label,'Leaving from')]");
	By input_LeavingFrom=By.xpath("//input[@placeholder='Where are you leaving from?']");
	By select_FirstLeavingFrom=By.xpath("//button[@class='SwapLocationsDesktop']/preceding::ul[@class='uitk-typeahead-results no-bullet']/li[@data-index='0']");
	By btn_GoingTo=By.xpath("//button[contains(@aria-label,'Going to')]");
	By input_GoingTo=By.xpath("//input[@placeholder='Where are you going to?']");
	By select_FirstGoingTo=By.xpath("//button[@class='SwapLocationsDesktop']/following::ul[@class='uitk-typeahead-results no-bullet']/li[@data-index='0']");
	By btn_DatePick=By.xpath("//button[contains(@aria-label,'Departing')]");
	By btn_Done=By.xpath("//button/span[text()='Done']");
	By btn_Search=By.xpath("//button[text()='Search' and @type='submit']");
	By btn_FlyingFrom=By.xpath("//button[contains(@aria-label,'Flying from')]");
	By btn_FlyingTo=By.xpath("//button[contains(@aria-label,'Flying to')]");
	By btn_Departing=By.xpath("//button[contains(@aria-label,'Departing')]");
	By btn_Returining=By.xpath("//button[contains(@aria-label,'Returning')]");
	
	By check_NonStop=By.xpath("//input[@id='stops-0' or @id='stopFilter_stops-0']");
	By select_PriceList=By.xpath("//select[@id='listings-sort' or @id='sortDropdown']");
	By option_PriceHighest=By.xpath("//select[@id='listings-sort' or @id='sortDropdown']/option[text()='Price (Highest)']");
	By option_FirstFlight=By.xpath("//ul[@data-test-id='listings' or @id='flightModuleList']/li[1]");
	By btn_Select=By.xpath("//ul[@data-test-id='listings' or @id='flightModuleList']/li[1]/descendant::button[@data-test-id='select-button']");
	By link_NoThanks=By.xpath("//a[@id='forcedChoiceNoThanks']");
	By lbl_TripSumary=By.xpath("//section[@class='tripSummaryContainer desktopView']/div/h2[text()='Trip Summary' and @class='tripSummaryHeader']");
	By btn_Continue=By.xpath("//button[text()='Continue' and @type='button' and @data-test-id='select-button']");
	By lbl_PriceSumary=By.xpath("//h2[text()='Price summary']");
	By lbl_FromToSumary=By.xpath("//h2[text()='San Francisco to New York']");
	By btn_CheckOut=By.xpath("//button[text()='Check out']");
	
	public OrbitzPageObjects() throws IOException {
		projectDirectory=getCurrentDirectory();
	}
	
	//Click Flights tab
	public void clickTab_Flights() {
		try {
			driver.findElement(tab_Flights).click();
			waitForPageToLoad(40);
			System.out.println("Clicked on Flights tab");
		}catch(Exception e) {
			System.out.println("Exception in clickTab_Flights, "+e);
		}
	}
	//Click Round Trip tab
	public void clickTab_RoundTrip() {
		try {
			driver.findElement(tab_RoundTrip).click();
			waitForPageToLoad(40);
			Thread.sleep(2000);
			System.out.println("Clicked on Round Trip tab");
		}catch(Exception e) {
			System.out.println("Exception in clickTab_RoundTrip, "+e);
		}
	}
	//Click Leaving From button
	public void click_LeavingFrom() {
		try {
			
			driver.findElement(btn_LeavingFrom).click();
			Thread.sleep(3000);
			waitForPageToLoad(40);
			System.out.println("Clicked on Leaving From button");
		}catch(Exception e) {
			System.out.println("Exception in click_LeavingFrom, "+e);
		}
	}
	//Set value for Leaving From text box
	public void SetValue_LeavingFrom(String leavingFromvalue) {
		try {
			driver.findElement(input_LeavingFrom).sendKeys(leavingFromvalue);
			waitForPageToLoad(40);
			Thread.sleep(3000);
			System.out.println("Set value '"+leavingFromvalue+"' for Leaving From text box");
		}catch(Exception e) {
			System.out.println("Exception in SetValue_LeavingFrom, "+e);
		}
	}
	//Click First value from search Leaving From button
	public void click_FirstValueLeavingFrom() {
		try {
			driver.findElement(select_FirstLeavingFrom).click();
			waitForPageToLoad(40);
			Thread.sleep(3000);
			System.out.println("Selected First value for Leaving From from Search result");
		}catch(Exception e) {
			System.out.println("Exception in click_FirstValueLeavingFrom, "+e);
		}
	}
	
	//Click Going To button
	public void click_GoingTo() {
		try {
			driver.findElement(btn_GoingTo).click();
			waitForPageToLoad(40);
			Thread.sleep(3000);
			System.out.println("Clicked on Going To button");
		}catch(Exception e) {
			System.out.println("Exception in click_GoingTo, "+e);
		}
	}
	//Set value for Going To text box
	public void SetValue_GoingTo(String goingToValue) {
		try {
			driver.findElement(input_GoingTo).sendKeys(goingToValue);
			waitForPageToLoad(40);
			Thread.sleep(3000);
			System.out.println("Set value '"+goingToValue+"' for Going To text box");
		}catch(Exception e) {
			System.out.println("Exception in SetValue_GoingTo, "+e);
		}
	}
	//Click First value from search Going To button
	public void click_FirstValueGoingTo() {
		try {
			driver.findElement(select_FirstGoingTo).click();
			waitForPageToLoad(40);
			Thread.sleep(3000);
			System.out.println("Selected First value for Going To from Search result");
		}catch(Exception e) {
			System.out.println("Exception in click_FirstValueGoingTo, "+e);
		}
	}
	
	//Click Date Picker button
	public void click_DatePicker() {
		try {
			driver.findElement(btn_DatePick).click();
			waitForPageToLoad(40);
			Thread.sleep(3000);
			System.out.println("Clicked on Date picker button");
		}catch(Exception e) {
			System.out.println("Exception in click_DatePicker, "+e);
		}
	}
	
	//Click Departing Date
	public void select_DepartingDate() {
		try {
			String departDt=getDateInRequiredFormate(14, "MMM dd, yyyy");
			String departDtXpath="//button[starts-with(@aria-label,'"+departDt+"')]";
			driver.findElement(By.xpath(departDtXpath)).click();
			waitForPageToLoad(40);
			System.out.println("Clicked on Departing date "+departDt);
		}catch(Exception e) {
			System.out.println("Exception in select_DepartingDate, "+e);
		}
	}
	//Click Returning Date
	public void select_returningDate() {
		try {
			String returnDt=getDateInRequiredFormate(21, "MMM dd, yyyy");
			String returnDtXpath="//button[@aria-label='"+returnDt+"']";
			driver.findElement(By.xpath(returnDtXpath)).click();
			waitForPageToLoad(40);
			System.out.println("Clicked on Returning date "+returnDt);
		}catch(Exception e) {
			System.out.println("Exception in select_returningDate, "+e);
		}
	}
	
	//Click Done button
	public void click_Done() {
		try {
			driver.findElement(btn_Done).click();
			waitForPageToLoad(40);
			System.out.println("Clicked on Done button");
		}catch(Exception e) {
			System.out.println("Exception in click_Done, "+e);
		}
	}
	
	//Click Search button
	public void click_Search() {
		try {
			driver.findElement(btn_Search).click();
			waitForPageToLoad(40);
			Thread.sleep(8000);
			System.out.println("Clicked on Search button");
		}catch(Exception e) {
			System.out.println("Exception in click_Search, "+e);
		}
	}
	//Click Search button
	@SuppressWarnings("deprecation")
	public void verify_FlightsSearch() {
		try {
			waitForPageToLoad(40);
			String flyFrom=driver.findElement(btn_FlyingFrom).getText();
			Assert.assertTrue(flyFrom.toLowerCase().contains("san francisco"));
			System.out.println("Assertion Successfull for Flying From 'San Francisco'");
			String flyTo=driver.findElement(btn_FlyingTo).getText();
			Assert.assertTrue(flyTo.toLowerCase().contains("new york"));
			System.out.println("Assertion Successfull for Flying From 'New York'");
			
			String depDate=getDateInRequiredFormate(14,"MMM dd");
			String depart=driver.findElement(btn_Departing).getText();
			Assert.assertTrue(depart.toLowerCase().contains(depDate.toLowerCase()));
			System.out.println("Assertion Successfull for Departing data as : "+depDate);
			
			String returnDate=getDateInRequiredFormate(21,"MMM dd");
			String returning=driver.findElement(btn_Returining).getText();
			Assert.assertTrue(returning.toLowerCase().contains(returnDate.toLowerCase()));
			System.out.println("Assertion Successfull for Returning data as : "+returnDate);
		}catch(Exception e) {
			System.out.println("Exception in verify_FlightsSearch, "+e);
		}
	}
	//Click Non Stop check box
	public void check_NonStop() {
		try {
			driver.findElement(check_NonStop).click();
			waitForPageToLoad(40);
			Thread.sleep(3000);
			System.out.println("Non Stop Check box selected");
		}catch(Exception e) {
			System.out.println("Exception in check_NonStop, "+e);
		}
	}
	public void selectValue_PriceListSorting(String valueToSelect) throws InterruptedException, IOException {
		try {			
			WebElement ddBox = driver.findElement(select_PriceList);
			Select s = new Select(ddBox);			
			if (ddBox.isDisplayed() && ddBox.isEnabled()) {
			s.selectByVisibleText(valueToSelect); 
			waitForPageToLoad(40);
			Thread.sleep(4000);
			System.out.println("'Price List' has been select to Value '" + valueToSelect+ "'");
			}else System.out.println("'Price List' has NOT been select to Value '" +valueToSelect + "'!!!");
					
		}catch(Exception e) {
			System.out.println("Issue in method selectPriceListSorting, "+e);
		}
		
	}
	
	public void selectPriceHighest() throws InterruptedException, IOException {
		try {
			driver.findElement(select_PriceList).click();
			driver.findElement(option_PriceHighest).click();
			Thread.sleep(5000);
			System.out.println("Price Sort By Selected as 'Price (Highest)'");				
		}catch(Exception e) {
			System.out.println("Issue in method selectPriceHighest, "+e);
		}
		
	}
	//Click First value for Highest price
	public void select_FirstValueForHighestPrice() {
		try {
			driver.findElement(option_FirstFlight).click();
			waitForPageToLoad(40);
			System.out.println("First value for Highest Price Flight selected");
		}catch(Exception e) {
			System.out.println("Exception in select_FirstValueForHighestPrice, "+e);
		}
	}
	//Click Continue button
	public void click_ContinueButton() {
		try {
			Thread.sleep(8000);
			driver.findElement(btn_Continue).click();
			Thread.sleep(8000);
			waitForPageToLoad(40);			
			System.out.println("Clicked Continue button");
		}catch(Exception e) {
			System.out.println("Exception in click_ContinueButton, "+e);
		}
	}
	//Click Select button
	public void click_SelectButton() {
		try {
			driver.findElement(btn_Select).click();
			waitForPageToLoad(40);
			System.out.println("click select button");
		}catch(Exception e) {
			System.out.println("Exception in click_SelectButton, "+e);
		}
	}
	//Click Select button
	public void click_NoThanks() {
		try {
			if(driver.findElement(link_NoThanks).isDisplayed())
				driver.findElement(link_NoThanks).click();
			waitForPageToLoad(40);
			System.out.println("click No Thanks Link");
		}catch(Exception e) {
			System.out.println("Exception in click_NoThanks, "+e);
		}
	}
	
	public String getCurrentDirectory() {
		projectDirectory = System.getProperty("user.dir");
		return projectDirectory;
	}
	public void launchBrowser(String browserName, String url) throws IOException {
		projectDirectory = getCurrentDirectory();
		switch(browserName) {	
		
		case "chrome":		
			System.setProperty("webdriver.chrome.driver", projectDirectory + "\\Driver\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			//options.addArguments("headless");
			options.setAcceptInsecureCerts(true);
			options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
			driver = new ChromeDriver(options);
			break;
		case "firefox":			
			System.setProperty("webdriver.gecko.driver", projectDirectory + "\\Driver\\geckodriver.exe");			
			driver = new FirefoxDriver();
			break;			
		case "ie":
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();			  
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			System.setProperty("webdriver.ie.driver", projectDirectory + "\\Driver\\IEDriverServer.exe");			
			driver = new InternetExplorerDriver(capabilities);
			break;
		}	

		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Browser has been launched, navigated to url :" + url);
	}
	
	public void closeBrowser() throws InterruptedException, IOException {
		driver.close();
		driver.quit();
		System.out.println("Browser has been closed successfully");
	}
	
	public boolean isElementExist(String xpath) throws IOException {
		try {
		WebElement element = driver.findElement(By.xpath(xpath));
		if (element.isDisplayed());
		}
		catch(Exception e) {
			System.out.println("Catch : exception occured in isElementExist(String xpath) ");
		}
		return true;
	}
	public String getDateInRequiredFormate(int daysAddOrRemove, String dateFormat) throws Exception{
		
		LocalDateTime currentDate = LocalDateTime.now();  
		LocalDateTime expDate = currentDate.plusDays(daysAddOrRemove);
		System.out.println("Before Formatting: " + expDate);  
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern(dateFormat);
	    String formattedDate = expDate.format(myFormatObj);  
	    char c=formattedDate.charAt(4);
		if(c=='0')formattedDate=formattedDate.substring(0,3)+" "+formattedDate.substring(5);
	    System.out.println("After Formatting: " + formattedDate); 
	    return formattedDate;		
			
	}
	public void waitForPageToLoad(int timeSecs) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, timeSecs);
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));
	}
	public void waitUntilElementDisplayed(By locator,int timeSecs) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, timeSecs);
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}
	public void waitUntilPageTitle(String title,int timeSecs) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, timeSecs);
		wait.until(ExpectedConditions.titleIs(title));
	}
	@SuppressWarnings("deprecation")
	public void assertTripSummaryPage() {
		Set<String> windowIds = driver.getWindowHandles();
		for (String id : windowIds) {
			driver.switchTo().window(id);
		}
		String pgTitle=driver.getTitle();
		System.out.println("Trip Page Title is "+pgTitle);
		Assert.assertEquals("Trip details | Orbitz", pgTitle);
		System.out.println("Assertion successfull for Page Title is "+pgTitle);
		Assert.assertTrue(driver.findElement(lbl_TripSumary).isDisplayed());
		System.out.println("Assertion successfull summary label ");
	}
	@SuppressWarnings("deprecation")
	public void assertFlightSummaryPage() throws InterruptedException {
		Set<String> windowIds = driver.getWindowHandles();
		for (String id : windowIds) {
			driver.switchTo().window(id);
		}
		waitUntilPageTitle("Flight details | Orbitz", 30);
		String pgTitle=driver.getTitle();
		System.out.println("Flights Page Title is "+pgTitle);
		Assert.assertEquals("Flight details | Orbitz", pgTitle);
		Assert.assertTrue(driver.findElement(lbl_PriceSumary).isDisplayed());
		System.out.println("Assertion successfull for 'Price summary' label ");
		Assert.assertTrue(driver.findElement(lbl_FromToSumary).isDisplayed());
		System.out.println("Assertion successfull for From To Locations 'San Francisco to New York' label ");
		Assert.assertTrue(driver.findElement(btn_CheckOut).isDisplayed());
		System.out.println("Assertion successfull for 'Check Out' label");
	}
	public void verify_FinalFlightsSummaryPage() {
		try {
			select_FirstValueForHighestPrice();
			waitUntilElementDisplayed(btn_Continue, 30);
			click_ContinueButton();			
			assertFlightSummaryPage();
			/*
			 * if(driver.findElement(btn_Select).isDisplayed()) { click_SelectButton();
			 * click_NoThanks(); assertTripSummaryPage(); }else {
			 * select_FirstValueForHighestPrice(); click_ContinueButton();
			 * assertFlightSummaryPage(); }
			 */
		}
		catch(Exception e) {
			System.out.println("Catch : exception occured in verify_FinalFlightsSummaryPage");
		}
		
	}
}
