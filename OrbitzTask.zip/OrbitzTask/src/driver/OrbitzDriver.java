
/*@Author: Pragna
@Date: 23-Jun-2021
@Description : This Driver will run the test*/

package driver;

import java.io.IOException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageobjects.*;

public class OrbitzDriver extends OrbitzPageObjects {
	
	OrbitzPageObjects orbit;
	OrbitzDriver() throws IOException{
		orbit = new OrbitzPageObjects();
	}
	

	@BeforeMethod
	public void preSetup() throws IOException {
		System.out.println("##################Starting test execution######################## ");
		launchBrowser("chrome", "https://www.orbitz.com/");		
	}

	@AfterMethod
	public void closeBrowserTest() throws InterruptedException, IOException {
		//closeBrowser();
		System.out.println("##################Ending test execution######################## ");
		
	}
	
	@Test(priority = 0, enabled = true)
	public void  orbitzTest() throws IOException,InterruptedException { 
		 clickTab_Flights();
		 clickTab_RoundTrip();
		 click_LeavingFrom();
		 SetValue_LeavingFrom("San Francisco");
		 click_FirstValueLeavingFrom();
		 click_GoingTo();
		 SetValue_GoingTo("New York");
		 click_FirstValueGoingTo();
		 click_DatePicker();
		 select_DepartingDate();
		 select_returningDate();
		 click_Done();
		 click_Search();
		 verify_FlightsSearch();
		 check_NonStop();
		 selectValue_PriceListSorting("Price (Highest)");
		 verify_FinalFlightsSummaryPage();
	 	  
	}	

}
